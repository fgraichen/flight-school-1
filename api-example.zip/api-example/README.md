Directory structure for API sync.
