#/bin/bash

set +x
set -e

api_management_protocol=$1
api_management_host=$2
api_management_port=$3
api_org=$4
api_env=$5
env_creds_base64=$6
api_name=$7
api_type=$8

git_repo_user=$9
git_repo_email=$10
api_debug=$11

set -x

# Diagnostics
pwd
id
ls -la
node --version
npm --version

# Pull down the API proxy from Apigee
echo "Running apigee fetchproxy"

if [ "$api_type" = "sharedflow" ]; then
  api_type_mgmt_folder="sharedflows"
  api_type_dir="sharedflowbundle"
else
  api_type_mgmt_folder="apis"
  api_type_dir="apiproxy"
fi

if [ "${api_debug}" = "true" ]; then
  set -x
else
  set +x
fi

#export NODE_PATH=/usr/local/lib/node_modules
export NODE_PATH=/usr/local/node/lib/node_modules

node api-repo-source/api-sync/api-sync-download.js $api_management_protocol $api_management_host $api_management_port $api_org $api_env $env_creds_base64 $api_name $api_type_mgmt_folder > /tmp/api-sync-download.log

echo "Return code from sync script is:  $?"
set -x

rm /tmp/api-sync-download.log

# Clone the API repo
git clone api-repo-source api-repo-source-out
unzip $api_name.zip
ls -la
ls api-repo-source
ls api-repo-source-out

#current_time=$(date +%s%3N)
#last_modified_time=`grep 'LastModifiedAt' apiproxy/$api_name.xml | awk -F '>' '{ print $2 }' | awk -F '<' '{ print $1 }'`
#interval_milli=`expr $current_time - $last_modified_time`

#echo "Current time:        " $current_time
#echo "Last modified time:  " $last_modified_time
#echo "Interval in ms:      " $interval_milli

#if [ "$interval_milli" -lt 300000 ]
#then
#  echo "Less than 5 minutes, sync new version to repo"

  cd api-repo-source-out
  mkdir -p $api_type_dir
  ls $api_type_dir

  set +e
  git rm -r $api_type_dir/*
  set -e

  rsync --recursive ../$api_type_dir .

  tree ../api-repo-source
  tree ../api-repo-source-out

  set +x
  git config --global user.email "$git_repo_email"
  git config --global user.name "$git_repo_user"
  set -x
  git config --global push.default simple
  git add .
  set +e
  git commit -m "Add $api_name contents for Apigee"
  echo "Commit return code = $?"
  set -e

#else
#  echo "Greater than 5 minutes, no sync"
#fi
