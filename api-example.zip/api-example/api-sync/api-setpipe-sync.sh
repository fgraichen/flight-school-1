#!/bin/bash

set -x
source ../api-deploy/api-sourcefile

fly -t dt-${product_target_tag} sync
fly -t dt-${product_target_tag} set-pipeline \
-p ${api_pipeline_name}-sync-${api_sync_org} \
-c api-pipe-sync.yml \
--var "api-sync-org=${api_sync_org}" \
--load-vars-from "../api-deploy/api-params-dev-${api_sync_org}.yml" \
--load-vars-from "../api-parms-common.yml"

fly -t dt-${product_target_tag} hide-pipeline -p ${api_pipeline_name}-sync-${api_sync_org}

set +x
echo " "
echo "fly -t dt-${product_target_tag} destroy-pipeline -p ${api_pipeline_name}-sync-${api_sync_org}"
echo "fly -t dt-${product_target_tag} expose-pipeline -p ${api_pipeline_name}-sync-${api_sync_org}"
echo "fly -t dt-${product_target_tag} get-pipeline -p ${api_pipeline_name}-sync-${api_sync_org}"
echo " "
