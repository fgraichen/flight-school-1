#!/bin/bash

set -x
export api_sync_org=cust

./api-setpipe-sync.sh
