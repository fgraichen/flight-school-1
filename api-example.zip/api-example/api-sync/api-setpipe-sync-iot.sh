#!/bin/bash

set -x
export api_sync_org=iot

./api-setpipe-sync.sh
