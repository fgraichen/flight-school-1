#!/bin/bash

set -x
export api_sync_org=emp

./api-setpipe-sync.sh
