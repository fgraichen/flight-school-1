#!/bin/sh
set -x

mvn --version
node --version
npm --version
java -version
id
pwd
ls

echo $1 " " $2
