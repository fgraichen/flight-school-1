#!/bin/sh
#set +x

if [ "${api_debug}" = "true" ]; then
  set -x
  export mvn_debug="-X"
else
  set +x
  export mvn_debug=""
fi

api_goal=$1
api_profile=$2
api_org=$3
api_env=$4
api_user=$5
api_passwd=$6
api_config_options=$7
api_mgmt_protocol=$8
api_mgmt_host=$9
api_mgmt_port=$10
api_name=$11
api_type=$12
api_artifactory=$13

cd api-repo-source

mvn ${mvn_debug} -f pom-api-deploy.xml ${api_goal} \
-P ${api_profile} \
-Dorg=${api_org} \
-Denv=${api_env} \
-Dusername=${api_user} \
-Dpassword=${api_passwd} \
-Dapigee.config.dir=target/resources/edge \
-Dapigee.config.options=${api_config_options} \
-Dapigee.config.exportDir=./target/test/integration \
-Dapigee.api.management.protocol=${api_mgmt_protocol} \
-Dapigee.api.management.host=${api_mgmt_host} \
-Dapigee.api.management.port=${api_mgmt_port} \
-Dapigee.api.name=${api_name} \
-Dapigee.api.type=${api_type} \
-Dapigee.api.artifactory=${api_artifactory}
