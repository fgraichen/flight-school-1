#!/bin/bash -ex

#
# This script will set the environment for EMP (org=1)
#

export shared_proxy=false

if [ ${shared_proxy} = "false" ] ; 
then
  ./api-setpipe.sh --org=1 --env=1 --type=1
  ./api-setpipe.sh --org=1 --env=2 --type=2
  ./api-setpipe.sh --org=1 --env=3 --type=2
  ./api-setpipe.sh --org=1 --env=4 --type=2
  ./api-setpipe.sh --org=1 --env=5 --type=2
else
  ./api-setpipe.sh --org=1 --env=1 --type=3
  ./api-setpipe.sh --org=1 --env=2 --type=3
  ./api-setpipe.sh --org=1 --env=3 --type=3
  ./api-setpipe.sh --org=1 --env=4 --type=3
  ./api-setpipe.sh --org=1 --env=5 --type=3
fi

exit
