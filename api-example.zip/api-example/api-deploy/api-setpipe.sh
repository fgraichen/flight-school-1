#!/bin/bash -x

#
# The documentation is for the api-setpipe.sh script called by other 
# front-end scripts.  It is also present in api-setpipe.sh, 
# and can be displayed via ./api-setpipe.sh --help
#
# We need 3 parameters for script called herein: ./api-setpipe.sh
#
# ./api-setpipe.sh [--help] | [-h]
# ./api-setpipe.sh --org=[1,2,3] --env=[1,2,3,4,5] --type=[1,2,3,4]
#
# --org: Organization: emp, cust, iot
#   1 emp
#   2 cust
#   3 iot
#
# --env: Environment: dev, tst, qa, prod
#   1 dev
#   2 tst
#   3 qa
#   4 uat
#   5 prod
#
# --type: Pipeline type: apiproxy-no-deploy, apiproxy-deploy, 
#                        sharedflow-deploy, resources
#   1 apiproxy-no-deploy
#   2 apiproxy-deploy
#   3 sharedflow-deploy
#   4 resources
#
# Ex. The call for:  ./api-setpipe.sh cust dev apiproxy-deploy
#
# Can be coded as either:
#
# ./api-setpipe.sh -o 2 -e 2 -t 2
# ./api-setpipe.sh --org=2 --env=2 --type=2
#

script_syntax() {
  set +x
  echo " "
  echo "We need 3 parameters for script: $0 "
  echo " "
  echo "$0 [--help] | [-h]"
  echo "$0 --org=[1,2,3] --env=[1,2,3,4,5] --org=[1,2] --type=[1,2,3]"
  echo "$0 -o [1,2,3] -e [1,2,3,4] -o [1,2] -t [1,2,3]"
  echo " "
  echo "--org: Organization: emp, cust, iot"
  echo "  1 emp"
  echo "  2 cust"
  echo "  3 iot"
  echo " "
  echo "--env: Environment: dev, tst, qa or prod"
  echo "  1 dev"
  echo "  2 tst"
  echo "  3 qa"
  echo "  4 uat"
  echo "  5 prod"
  echo " "
  echo "--type: Type of pipeline.  apiproxy-no-deploy, apiproxy-deploy, sharedflow-deploy"
  echo "  1 apiproxy-no-deploy"
  echo "  2 apiproxy-deploy"
  echo "  3 sharedflow-deploy"
  echo "  4 common-resources-deploy"
  echo " "
  echo "Ex. The request:  $0 dev cust apiproxy-deploy"
  echo " "
  echo "Can be coded as: "
  echo " "
  echo "$0 -e 2 -o 2 -t 2"
  echo "$0 --env=2 --org=2 --type=2"
  echo " "
  set -x
}

#if [ $# -ne 3 ]
#then
#  script_syntax
#  exit 99
#fi

#env=$1
#if [ "$env" -ne "dev" && "$env" -ne "tst" && "$env" -ne "qa" && "$env" -ne "prod"]; then
#  echo "Invalid environment"
#  script_syntax
#  exit 99
#fi

#org=$2
#if [ "$org" -ne "emp" && "$org" -ne "cust" ]; then
#  echo "Invalid organization"
#  script_syntax
#  exit 99
#fi

#pipeline_file=$3
#if [! -f ${pipeline_file}]; then
#  echo "Pipeline file doesn't exist"
#  script_syntax
#  exit 99
#fi


# Parse specified line parameters

while [ "$#" -gt 0 ]; do
  case "$1" in
  -e) input_env="$2"
    shift 2
  ;;

  -o) input_org="$2"
    shift 2
  ;;

  -t) input_type="$2"
    shift 2
  ;;

  -h) script_syntax
    exit 1
  ;;

  --env=*) input_env="${1#*=}"
    shift 1
  ;;

  --org=*) input_org="${1#*=}"
    shift 1
  ;;

  --type=*) input_type="${1#*=}"
    shift 1
  ;;

  --help) script_syntax
    exit 1
  ;;

  --env|--org|--type) echo "$1 requires an argument" >&2
    exit 1
  ;;

  -*) echo " "
    echo "######################################"
    echo "Unknown option specified: $1" >&2
    echo "######################################"
    echo " "
    script_syntax
    exit 1
  ;;

  *) echo " "
    echo "######################################"
    echo "Unrecognized argument provided: $1" >&2
    echo "######################################"
    echo " "
    script_syntax
    exit 1
  ;;
  esac
done


# Which environment?

if [ -z ${input_env} ] ;
then
  echo "Which environment are we in? "
  echo "1 dev "
  echo "2 tst "
  echo "3 qa  "
  echo "4 uat"
  echo "5 prod"
  echo -n "? "
  read input_env
  echo " "
fi

case ${input_env} in
1)
  api_env="dev"
  api_target="dt"
  ;;

2)
  api_env="tst"
  api_target="dt"
  ;;

3)
  api_env="qa"
  ;;

4)
  api_env="uat"
  ;;

5)
  api_env="prod"
  ;;

*)
  echo "Environment input needs to be 1-5"
  echo " "
  exit 1
  ;;
esac

# Which org ?

if [ -z ${input_org} ] ;
then
  echo "Which organization are we in?"
  echo "1 emp "
  echo "2 cust"
  echo "3 iot"
  echo -n "? "
  read input_org
  echo " "
fi

case ${input_org} in
1)
  api_org="emp"
  if [ ${api_env} = "qa" ] || [ ${api_env} = "uat" ] || [ ${api_env} = "prod" ] ; 
  then
    api_target="emp"
  fi
  ;;

2)
  api_org="cust"
  if [ ${api_env} = "qa" ] || [ ${api_env} = "uat" ] || [ ${api_env} = "prod" ] ; 
  then
    api_target="cust"
  fi
  ;;

3)
  api_org="iot"
  if [ ${api_env} = "qa" ] || [ ${api_env} = "uat" ] || [ ${api_env} = "prod" ] ; 
  then
    #api_target="iot"
    api_target="cust"
  fi
  ;;

*)
  echo "Organization input needs to be 1-3"
  echo " "
  exit 1
  ;;
esac

# Which pipeline?

if [ -z ${input_type} ] ;
then
  echo "Which type pipeline are we using?"
  echo "1 apiproxy-no-deploy"
  echo "2 apiproxy-deploy"
  echo "3 sharedflow-deploy"
  echo "4 common-resources-deploy"
  echo -n "? "
  read input_type
  echo " "
fi

case ${input_type} in
1)
  api_pipeline="api-pipe-apiproxy-nodeploy.yml"
  ;;

2)
  api_pipeline="api-pipe-apiproxy.yml"
  ;;

3)
  api_pipeline="api-pipe-sharedflow.yml"
  ;;

4)
  api_pipeline="api-pipe-resources-common.yml"
  ;;

*)
  echo "Pipeline type input needs to be 1-3"
  echo " "
  exit 1
  ;;
esac

set -x
source api-sourcefile

fly -t ${api_target}-${product_target_tag} sync
fly -t ${api_target}-${product_target_tag} set-pipeline \
-p ${api_pipeline_name}-${api_env}-${api_org} \
-c ${api_pipeline} \
--load-vars-from "../api-parms-common.yml" \
--load-vars-from "api-params-${api_env}-${api_org}.yml"

#--var "api-artifactory-uri=NONE" \

if [ ${api_target} == "emp" ] || [ ${api_target} == "cust" ] ;
then
  fly -t ${api_target}-${product_target_tag} expose-pipeline -p ${api_pipeline_name}-${api_env}-${api_org}
else
  fly -t ${api_target}-${product_target_tag} hide-pipeline -p ${api_pipeline_name}-${api_env}-${api_org}
fi

set +x
echo " "
echo "fly -t ${api_target}-${product_target_tag} get-pipeline -p ${api_pipeline_name}-${api_env}-${api_org}"
echo "fly -t ${api_target}-${product_target_tag} destroy-pipeline -p ${api_pipeline_name}-${api_env}-${api_org}"
echo " "
